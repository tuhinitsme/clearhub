/* Topic filter for lists of items.
   Markup: buttons with data-filter="topic" (or "all") inside [data-filter-group],
   items with data-topics="topic-one topic-two" inside [data-filter-list],
   and an optional <p data-filter-empty hidden> shown when nothing matches. */
(function () {
    'use strict';

    var group = document.querySelector('[data-filter-group]');
    var list = document.querySelector('[data-filter-list]');
    if (!group || !list) { return; }

    var buttons = [].slice.call(group.querySelectorAll('[data-filter]'));
    var items = [].slice.call(list.querySelectorAll('[data-topics]'));
    var empty = document.querySelector('[data-filter-empty]');
    var status = document.querySelector('[data-filter-status]');

    function apply(topic) {
        var shown = 0;
        items.forEach(function (item) {
            var match = topic === 'all' || item.getAttribute('data-topics').split(' ').indexOf(topic) > -1;
            item.hidden = !match;
            if (match) { shown++; }
        });
        buttons.forEach(function (b) {
            b.setAttribute('aria-pressed', b.getAttribute('data-filter') === topic ? 'true' : 'false');
        });
        if (empty) { empty.hidden = shown !== 0; }
        if (status) { status.textContent = shown + (shown === 1 ? ' item shown' : ' items shown'); }
    }

    buttons.forEach(function (b) {
        b.addEventListener('click', function () { apply(b.getAttribute('data-filter')); });
    });

    [].forEach.call(document.querySelectorAll('[data-filter-reset]'), function (r) {
        r.addEventListener('click', function () { apply('all'); });
    });

    apply('all');
})();
