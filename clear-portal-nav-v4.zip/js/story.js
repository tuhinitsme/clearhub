const categories = [

{
name:"Place",
questions:[

{
question:"Where is this case study located?",
answer:"Signal Tower Colony, Mongla, Bangladesh",
options:[
"Jakarta, Indonesia",
"Signal Tower Colony, Mongla, Bangladesh",
"Nairobi, Kenya",
"Mumbai, India"
]
},

{
question:"What is it like here?",
answer:"Little fresh water and high poverty levels",
options:[
"Luxury housing and reliable water",
"Little fresh water and high poverty levels",
"Modern city infrastructure",
"High income community"
]
},

{
question:"What can you find out about this place?",
answer:"The community is mostly climate-induced migrants",
options:[
"The community is mostly climate-induced migrants",
"The settlement started in 2025",
"Most residents are wealthy",
"Population is below 100"
]
}

]
},

{
name:"People",
questions:[

{
question:"Who are stakeholders involved?",
answer:"Government, NGOs, Women, Children",
options:[
"Government, NGOs, Women, Children",
"Professional Athletes",
"Tourists",
"Movie Producers"
]
},

{
question:"Who is affected?",
answer:"Silpi and her neighbours",
options:[
"Silpi and her neighbours",
"Airline operators",
"Investors",
"Tourists"
]
}

]
},

{
name:"Issues",
questions:[

{
question:"What is one important issue?",
answer:"Contaminated and unreliable water",
options:[
"Airport congestion",
"Contaminated and unreliable water",
"Tourism decline",
"Sport facilities"
]
},

{
question:"Why are these issues important?",
answer:"People become sick from contaminated water and dehydration",
options:[
"People become sick from contaminated water and dehydration",
"Less entertainment",
"Traffic congestion",
"Housing demand"
]
}

]
},

{
name:"Solutions",
questions:[

{
question:"How do people respond?",
answer:"Buy water and walk long distances",
options:[
"Build airports",
"Buy water and walk long distances",
"Create malls",
"Expand tourism"
]
},

{
question:"What is one possible solution?",
answer:"Rainwater harvesting systems",
options:[
"Luxury housing",
"Rainwater harvesting systems",
"More cinemas",
"Airline expansion"
]
}

]
}

];

let currentCategory = 0;
let draggedItem = null;

function renderCategory(index){

    currentCategory = index;

    const container =
        document.getElementById("question-container");

    container.innerHTML = "";

    categories[index].questions.forEach((q,qIndex)=>{

        let html = `
        <div class="question-card">

            <div class="question">
                ${q.question}
            </div>

            <div class="dropzone"
                 data-answer="${q.answer}">
            </div>

            <div class="option-bank">
        `;

        q.options
        .sort(()=>Math.random()-0.5)
        .forEach(option=>{

            html += `
            <div class="option"
                 draggable="true">
                ${option}
            </div>
            `;
        });

        html += `
            </div>
        </div>
        `;

        container.innerHTML += html;
    });

    attachEvents();

    updateTabs();

    updateProgress();
}

function attachEvents(){

    document.querySelectorAll(".option")
    .forEach(option=>{

        option.addEventListener("dragstart",()=>{

            draggedItem = option;

        });

    });

    document.querySelectorAll(".dropzone")
    .forEach(zone=>{

        zone.addEventListener("dragover",(e)=>{

            e.preventDefault();

        });

        zone.addEventListener("drop",(e)=>{

            e.preventDefault();

            zone.innerHTML = "";

            zone.appendChild(draggedItem);

        });

    });

}

function checkAnswers(){

    let correct = 0;

    let total =
    document.querySelectorAll(".dropzone").length;

    document.querySelectorAll(".dropzone")
    .forEach(zone=>{

        zone.classList.remove("correct","wrong");

        const answer =
            zone.dataset.answer;

        const chosen =
            zone.querySelector(".option");

        if(
            chosen &&
            chosen.innerText.trim() === answer
        ){

            correct++;

            zone.classList.add("correct");

        }else{

            zone.classList.add("wrong");

        }

    });

    document.getElementById("scoreBox")
    .innerHTML =
    `🎯 Score: ${correct} / ${total}`;
}

function showCategory(index){

    renderCategory(index);
}

function nextCategory(){

    if(currentCategory < categories.length-1){

        renderCategory(currentCategory+1);

    }else{

        alert("🎉 Congratulations! You completed all categories.");
    }
}

function previousCategory(){

    if(currentCategory>0){

        renderCategory(currentCategory-1);
    }
}

function updateTabs(){

    document.querySelectorAll(".tab-btn")
    .forEach(btn=>btn.classList.remove("active"));

    document.querySelectorAll(".tab-btn")
    [currentCategory]
    .classList.add("active");
}

function updateProgress(){

    document.getElementById("progress-bar")
    .style.width =
    ((currentCategory+1)/categories.length*100)
    +"%";

}

renderCategory(0);