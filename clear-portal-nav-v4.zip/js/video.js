/* Click-to-load YouTube videos: nothing is requested from YouTube until the visitor presses play.
   Markup: <div class="video-embed" data-youtube-id="VIDEO_ID" data-title="Video title"></div> */
(function () {
    'use strict';

    [].forEach.call(document.querySelectorAll('.video-embed[data-youtube-id]'), function (box) {
        var id = box.getAttribute('data-youtube-id');
        var title = box.getAttribute('data-title') || 'Video';

        var btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'video-embed__play';
        btn.setAttribute('aria-label', 'Play video: ' + title);
        btn.innerHTML = '<span class="icon" aria-hidden="true">▶</span>' +
            '<span>' + title + '</span>' +
            '<small>Loads from YouTube when you press play</small>';
        box.appendChild(btn);

        btn.addEventListener('click', function () {
            var f = document.createElement('iframe');
            f.src = 'https://www.youtube-nocookie.com/embed/' + encodeURIComponent(id) + '?autoplay=1&rel=0';
            f.title = title;
            f.allow = 'accelerometer; autoplay; encrypted-media; picture-in-picture; fullscreen';
            f.allowFullscreen = true;
            box.replaceChild(f, btn);
            f.focus();
        });
    });
})();
