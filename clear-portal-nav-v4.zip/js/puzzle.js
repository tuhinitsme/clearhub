const imageUrl = "images/img1.jpg";

const board = document.getElementById("board");
const pool = document.getElementById("pool");
const message = document.getElementById("message");
const moveCounter = document.getElementById("moves");

const totalPieces = 9;

let draggedElement = null;
let moves = 0;

function createBoard(){

    board.innerHTML = "";
    pool.innerHTML = "";
    message.innerHTML = "";

    for(let i=0;i<totalPieces;i++){

        const slot =
        document.createElement("div");

        slot.classList.add("slot");
        slot.dataset.index = i;

        slot.addEventListener(
            "dragover",
            e=>e.preventDefault()
        );

        slot.addEventListener(
            "drop",
            dropPiece
        );

        board.appendChild(slot);
    }

    const indices =
    [...Array(totalPieces).keys()];

    indices.sort(
        ()=>Math.random()-0.5
    );

    indices.forEach(index=>{

        const piece =
        document.createElement("div");

        piece.classList.add("piece");

        piece.draggable = true;

        piece.dataset.correctIndex =
        index;

        const x =
        (index % 3) * -100;

        const y =
        Math.floor(index / 3) * -100;

        piece.style.backgroundImage =
        `url('${imageUrl}')`;

        piece.style.backgroundPosition =
        `${x}px ${y}px`;

        piece.style.backgroundSize =
        "300px 300px";

        piece.addEventListener(
            "dragstart",
            ()=>{
                draggedElement = piece;
            }
        );

        pool.appendChild(piece);
    });
}

function dropPiece(e){

    e.preventDefault();

    const targetSlot =
    e.currentTarget;

    if(
        draggedElement &&
        targetSlot.children.length===0
    ){

        targetSlot.appendChild(
            draggedElement
        );

        moves++;

        moveCounter.textContent =
        moves;

        checkWinCondition();
    }
}

function checkWinCondition(){

    const slots =
    document.querySelectorAll(".slot");

    let solved = true;

    slots.forEach(slot=>{

        const piece =
        slot.querySelector(".piece");

        if(
            !piece ||
            parseInt(piece.dataset.correctIndex)
            !==
            parseInt(slot.dataset.index)
        ){

            solved = false;
        }
    });

    if(
        solved &&
        document.querySelectorAll(
            ".slot .piece"
        ).length===9
    ){

        message.innerHTML = `
        <div class="success">
            🎉 Congratulations!
            <br><br>
            Puzzle Solved!
            <br><br>
            Total Moves: ${moves}
        </div>`;
    }
}

function resetGame(){

    moves = 0;

    moveCounter.textContent = "0";

    createBoard();
}

createBoard();