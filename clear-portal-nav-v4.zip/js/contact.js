/* Contact us page: fills in email, address and map from CONTACT in js/nav.js,
   and runs the contact form (validation, spam trap, sending).

   HOW THE FORM SENDS (set in js/nav.js → CONTACT):
     formAction : a form-handling endpoint such as Formspree ('https://formspree.io/f/xxxx').
                  Messages go to the inbox linked to that endpoint and are not public.
     email      : used as a fallback – the visitor's email app opens with the message ready.
   If neither is set, the form shows that it is not connected yet. */
(function () {
    'use strict';

    var C = (window.ClearHub && window.ClearHub.contact) || {};

    function text(sel, value, link) {
        var el = document.querySelector(sel);
        if (!el) { return; }
        if (!value) { el.innerHTML = '<span class="tbd">To be added</span>'; return; }
        if (link) {
            var a = document.createElement('a');
            a.href = link; a.textContent = value; el.textContent = ''; el.appendChild(a);
        } else { el.textContent = value; }
    }

    text('[data-contact-email]', C.email, C.email ? 'mailto:' + C.email : '');
    text('[data-contact-address]', C.address, '');

    /* ---------- map (loads only when asked) ---------- */
    var mapBox = document.querySelector('[data-contact-map]');
    if (mapBox) {
        if (C.mapUrl) {
            mapBox.innerHTML = '<button type="button" class="btn" data-show-map>🗺️ Show map</button>' +
                (C.mapLink ? ' <a href="' + C.mapLink + '" target="_blank" rel="noopener">Open in Maps</a>' : '');
            mapBox.querySelector('[data-show-map]').addEventListener('click', function () {
                var f = document.createElement('iframe');
                f.src = C.mapUrl; f.title = 'Location map'; f.loading = 'lazy';
                f.referrerPolicy = 'no-referrer-when-downgrade'; f.className = 'map-frame';
                mapBox.innerHTML = ''; mapBox.appendChild(f);
            });
        } else {
            mapBox.innerHTML = '<div class="map-empty">🗺️ Map to be added</div>';
        }
    }

    /* ---------- form ---------- */
    var form = document.getElementById('contact-form');
    if (!form) { return; }
    var status = document.getElementById('cf-status');
    var submit = form.querySelector('button[type="submit"]');
    var connected = !!(C.formAction || C.email);

    if (!connected) {
        status.className = 'form-status form-status--warn';
        status.textContent = 'The contact form is not connected yet. Please check back soon.';
        submit.disabled = true;
    }

    var RULES = {
        name:    function (v) { return v.trim().length >= 2 ? '' : 'Please enter your name.'; },
        email:   function (v) { return /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v.trim()) ? '' : 'Please enter a valid email address.'; },
        topic:   function (v) { return v ? '' : 'Please choose a topic.'; },
        message: function (v) { return v.trim().length >= 10 ? '' : 'Please write at least a short sentence (10 characters).'; },
        consent: function (v, el) { return el.checked ? '' : 'Please tick the box so we can reply to you.'; }
    };

    function check(name) {
        var el = form.elements[name];
        var err = document.getElementById('cf-' + name + '-err');
        var msg = RULES[name](el.value, el);
        el.setAttribute('aria-invalid', msg ? 'true' : 'false');
        err.textContent = msg;
        err.hidden = !msg;
        return !msg;
    }

    Object.keys(RULES).forEach(function (name) {
        var el = form.elements[name];
        el.addEventListener('blur', function () { check(name); });
        el.addEventListener('input', function () { if (el.getAttribute('aria-invalid') === 'true') { check(name); } });
    });

    function show(kind, msg) {
        status.className = 'form-status form-status--' + kind;
        status.textContent = msg;
        status.focus();
    }

    form.addEventListener('submit', function (e) {
        e.preventDefault();
        var firstBad = null;
        Object.keys(RULES).forEach(function (n) { if (!check(n) && !firstBad) { firstBad = form.elements[n]; } });
        if (firstBad) { firstBad.focus(); return; }

        if (form.elements.website.value) {            // spam trap filled in by bots
            show('ok', 'Thank you. Your message has been sent.');
            form.reset();
            return;
        }

        var data = {
            name: form.elements.name.value.trim(),
            email: form.elements.email.value.trim(),
            organisation: form.elements.organisation.value.trim(),
            topic: form.elements.topic.value,
            message: form.elements.message.value.trim()
        };

        if (C.formAction) {
            submit.disabled = true;
            submit.textContent = 'Sending…';
            fetch(C.formAction, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
                body: JSON.stringify(data)
            }).then(function (r) {
                if (!r.ok) { throw new Error('HTTP ' + r.status); }
                show('ok', 'Thank you, ' + data.name + '. Your message has been sent and we will reply by email.');
                form.reset();
            }).catch(function () {
                show('error', 'Sorry, your message could not be sent.' +
                    (C.email ? ' Please email us at ' + C.email + '.' : ' Please try again later.'));
            }).then(function () {
                submit.disabled = false;
                submit.textContent = 'Send message';
            });
        } else {
            var body = 'Name: ' + data.name + '\nEmail: ' + data.email +
                (data.organisation ? '\nOrganisation: ' + data.organisation : '') + '\n\n' + data.message;
            location.href = 'mailto:' + C.email + '?subject=' + encodeURIComponent('[CLEAR Hub] ' + data.topic) +
                '&body=' + encodeURIComponent(body);
            show('ok', 'Your email app should open with the message ready to send. If it does not, write to ' + C.email + '.');
        }
    });
})();
