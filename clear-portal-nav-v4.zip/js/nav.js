/*
 * CLEAR Hub – shared navigation, language switch, breadcrumbs, landing-page cards and footer
 * ==========================================================================================
 * HOW TO EDIT THE MENU
 *   Change the NAV list below. Every page picks it up automatically:
 *   the top menu, breadcrumbs, footer links and the card grids on landing pages.
 *     label    : English text shown in the menu
 *     bn       : Bangla text shown when the visitor chooses বাংলা
 *     href     : page file (add #section to point at part of a page)
 *     desc     : one line shown on landing-page cards (English)
 *     icon     : emoji shown on landing-page cards
 *     children : optional sub-items (menu shows the top level + two levels below)
 *     default  : true on the item that counts as "current" when the page
 *                is opened without a #section
 *
 * HOW TO ADD A PAGE
 *   1. Copy page-template.html to the new file name and edit its text.
 *   2. Add an entry for it in NAV below (with its Bangla label).
 *   Pages that sit inside a section but not in the menu (e.g. a single article) add
 *   data-parent="articles.html" to <body> and get the right breadcrumb automatically.
 *
 * LANGUAGE SWITCH
 *   The menu, breadcrumbs and footer switch between English and Bangla.
 *   Page content is English only for now, so in Bangla mode a notice explains this.
 *   When a translated page exists, add to that page's <head> (and to its English twin):
 *     <link rel="alternate" hreflang="bn" href="articles.bn.html">
 *     <link rel="alternate" hreflang="en" href="articles.html">
 *   The switch then takes the visitor to the matching page automatically.
 *   NOTE: the Bangla menu labels below are a first draft and need human review.
 */
(function () {
  'use strict';

  var NAV = [
    { label: 'Home', bn: 'হোম', href: 'index.html', icon: '🏠' },

    { label: 'Climate Explained', bn: 'জলবায়ু সহজ ভাষায়', href: 'climate-explained.html', icon: '🌦️',
      desc: 'Plain-language explanations of climate research, with links to the original sources.',
      children: [
        { label: 'Articles', bn: 'নিবন্ধ', href: 'articles.html', icon: '📝',
          desc: 'Short articles that explain what research asked, found and why it matters.' },
        { label: 'Briefs and Visual Summaries', bn: 'সংক্ষিপ্ত বিবরণী ও ভিজ্যুয়াল সারসংক্ষেপ', href: 'briefs.html', icon: '🗂️',
          desc: 'Quick, visual overviews you can read and share in minutes.',
          children: [
            { label: 'Country Brief', bn: 'দেশভিত্তিক সংক্ষিপ্ত বিবরণ', href: 'country-brief.html', icon: '🗺️',
              desc: 'A summary of findings and lessons from the Bangladesh Creative Communication Package.' }
          ] },
        { label: 'Blogs', bn: 'ব্লগ', href: 'blogs.html', icon: '✍️',
          desc: 'Reflections and commentary on climate learning and communication.' },
        { label: 'News', bn: 'সংবাদ', href: 'news.html', icon: '📰',
          desc: 'Updates and news on climate research, learning and this portal.' },
        { label: 'Reports', bn: 'প্রতিবেদন', href: 'reports.html', icon: '📑',
          desc: 'Longer publications, with summaries and links to the full documents.' }
      ] },

    { label: 'Explore and Learn', bn: 'অন্বেষণ ও শিখুন', href: 'explore-and-learn.html', icon: '🧭',
      desc: 'Discover climate change through stories, visuals, and activities.',
      children: [
        { label: 'Stories and Puzzles', bn: 'গল্প ও ধাঁধা', href: 'stories-and-puzzles.html', icon: '🧩',
          desc: 'Work through a community story and solve the interactive comic puzzle.',
          children: [
            { label: 'Stories', bn: 'গল্প', href: 'stories-and-puzzles.html#stories', icon: '📖', default: true,
              desc: 'Explore a real case study through Place, People, Issues and Solutions.' },
            { label: 'Comic Puzzle', bn: 'কমিক ধাঁধা', href: 'stories-and-puzzles.html#comic-puzzle', icon: '🧩',
              desc: 'Rebuild the comic by dragging the pieces into place.' }
          ] },
        { label: 'Watch and Learn', bn: 'দেখুন ও শিখুন', href: 'watch-and-learn.html', icon: '🎬',
          desc: 'Short videos that show how to use the materials and share community experiences.',
          children: [
            { label: 'How to Use Video', bn: 'ব্যবহারের ভিডিও', href: 'how-to-use-video.html', icon: '▶️',
              desc: 'A short demonstration showing how to use the communication materials in learning sessions.' },
            { label: 'Silpi', bn: 'শিল্পী', href: 'silpi.html', icon: '🎞️',
              desc: 'Watch the Silpi video.' }
          ] }
      ] },

    { label: 'Practical Tools', bn: 'ব্যবহারিক সরঞ্জাম', href: 'practical-tools.html', icon: '🧰',
      desc: 'Ready-to-use resources for communicators, educators and facilitators.',
      children: [
        { label: 'Climate Communication Toolkit', bn: 'জলবায়ু যোগাযোগ টুলকিট', href: 'communication-toolkit.html', icon: '🧰',
          desc: 'Cards, guides, activities and videos for communicating climate issues.',
          showChildDesc: true,      // show each item's one-line brief under its name in the menu
          children: [
            { label: 'Frogis Card', bn: 'ফ্রগিস কার্ড', href: 'frogis-card.html', icon: '🎴',
              desc: 'Visual cards that encourage conversations about climate risks, adaptation, inclusion, and shared experiences. Use them in workshops, classrooms, and group activities.' },
            { label: 'Facilitator Guide', bn: 'সহায়কের নির্দেশিকা', href: 'facilitator-guide.html', icon: '📘',
              desc: 'A practical guide explaining how to use the cards and comic puzzle with different groups.' },
            { label: 'Interactive Comic Puzzle', bn: 'ইন্টারঅ্যাকটিভ কমিক ধাঁধা', href: 'stories-and-puzzles.html#comic-puzzle', icon: '🧩',
              desc: 'A storytelling activity where participants arrange comic panels and discuss climate adaptation experiences together.' },
            { label: 'How to Use Video', bn: 'ব্যবহারের ভিডিও', href: 'how-to-use-video.html', icon: '▶️',
              desc: 'A short demonstration showing how to use the communication materials in learning sessions.' },
            { label: 'Country Brief', bn: 'দেশভিত্তিক সংক্ষিপ্ত বিবরণ', href: 'country-brief.html', icon: '🗺️',
              desc: 'A summary of findings and lessons from the Bangladesh Creative Communication Package.' }
          ] }
      ] },

    { label: 'About and Collaborate', bn: 'পরিচিতি ও সহযোগিতা', href: 'about.html', icon: '🤝',
      desc: 'Who we are, how we work and ways to collaborate.',
      children: [
        { label: 'About us', bn: 'আমাদের সম্পর্কে', href: 'about-us.html', icon: 'ℹ️',
          desc: 'What CLEAR Hub is, what it covers and who it is for.' },
        { label: 'Theory of Change', bn: 'পরিবর্তনের তত্ত্ব', href: 'theory-of-change.html', icon: '🔄',
          desc: 'How our activities are meant to lead to change.' },
        { label: 'Visiting Researcher', bn: 'ভিজিটিং গবেষক', href: 'visiting-researcher.html', icon: '🎓',
          desc: 'Information for researchers who want to visit and work with us.' },
        { label: 'Team', bn: 'আমাদের দল', href: 'team.html', icon: '👥',
          desc: 'The people behind CLEAR Hub.' }
      ] }
  ];

  /* ------------------------------------------------------------------ */
  /* CONTACT DETAILS – used by the Contact us page (contact.html)       */
  /* and the footer social links. Empty ones show "To be added".         */
  /*   email   : 'name@example.org'                                       */
  /*   address : 'Street, City, Country'                                  */
  /*   mapUrl  : the "src" of a Google Maps or OpenStreetMap embed        */
  /*             (Google Maps: Share > Embed a map > copy the src="…")    */
  /*   mapLink : normal link that opens the place in Maps (optional)      */
  /*   social  : full profile URLs                                        */
  /* ------------------------------------------------------------------ */
  var CONTACT = {
    email: '',
    address: '',
    mapUrl: '',
    mapLink: '',
    formAction: '',     // contact form endpoint, e.g. a Formspree URL: 'https://formspree.io/f/xxxxxxx'
    social: { facebook: '', linkedin: '', bluesky: '' }
  };

  // Pages that appear only in the footer (not in the main menu).
  var FOOTER_LINKS = [
    { label: 'Contact us', bn: 'যোগাযোগ করুন', href: 'contact.html' }
  ];

  var UI = {
    en: { home: 'Home', crumb: 'Breadcrumb', includes: 'Includes', rights: '© 2026 CLEAR Hub',
          credit: 'Tech Action fulfilled by', menu: 'Menu', submenu: ' submenu',
          explore: 'Explore', follow: 'Follow us', tbd: 'To be added',
          tagline: 'Making climate research clear for everyone.', social: { facebook: 'Facebook', linkedin: 'LinkedIn', bluesky: 'Bluesky' } },
    bn: { home: 'হোম', crumb: 'পথনির্দেশ', includes: 'অন্তর্ভুক্ত', rights: '© ২০২৬ ক্লিয়ার হাব',
          credit: 'প্রযুক্তি সহায়তা:', menu: 'মেনু', submenu: ' সাবমেনু',
          explore: 'অন্বেষণ', follow: 'আমাদের অনুসরণ করুন', tbd: 'শীঘ্রই যুক্ত করা হবে',
          tagline: 'জলবায়ু গবেষণা সবার জন্য স্পষ্ট করা।', social: { facebook: 'ফেসবুক', linkedin: 'লিংকডইন', bluesky: 'ব্লুস্কাই' },
          notice: 'মেনু বাংলায় দেখানো হচ্ছে, কিন্তু এই পৃষ্ঠার বিষয়বস্তু আপাতত শুধু ইংরেজিতে পাওয়া যায়।',
          switchTo: 'English-এ দেখুন' }
  };

  /* ------------------------------------------------------------------ */
  /* helpers                                                            */
  /* ------------------------------------------------------------------ */
  var DESKTOP = window.matchMedia('(min-width: 1100px)');
  var lang = 'en';

  function esc(s) {
    return String(s).replace(/[&<>"]/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c];
    });
  }

  function T(item) { return lang === 'bn' && item.bn ? item.bn : item.label; }

  function store(key, val) {
    try { if (val === undefined) { return localStorage.getItem(key); } localStorage.setItem(key, val); }
    catch (e) { return null; }
  }

  function initLang() {
    var q = /[?&]lang=(en|bn)/.exec(location.search);
    var saved = q ? q[1] : store('clearhub-lang');
    lang = saved === 'bn' ? 'bn' : 'en';
    if (q) { store('clearhub-lang', lang); }
    document.documentElement.lang = lang;
  }

  function currentFile() {
    var f = location.pathname.split('/').pop() || 'index.html';
    if (f.indexOf('.') < 0) { f += '.html'; }   // clean URLs such as /articles
    return f;
  }

  function isHere(item) {
    var i = item.href.indexOf('#');
    var file = i < 0 ? item.href : item.href.slice(0, i);
    var hash = i < 0 ? '' : item.href.slice(i);
    if (file !== currentFile()) { return false; }
    if (!hash) { return true; }
    return hash === location.hash || (!location.hash && item.default === true);
  }

  /* Path from the top of the menu down to the current page (first match wins). */
  function findTrail(items, test) {
    for (var i = 0; i < items.length; i++) {
      var it = items[i];
      var deeper = it.children ? findTrail(it.children, test) : null;
      if (deeper) { return [it].concat(deeper); }
      if (test(it)) { return [it]; }
    }
    return null;
  }

  function findByLabel(items, label) {
    for (var i = 0; i < items.length; i++) {
      if (items[i].label === label) { return items[i]; }
      var d = items[i].children ? findByLabel(items[i].children, label) : null;
      if (d) { return d; }
    }
    return null;
  }

  /* ------------------------------------------------------------------ */
  /* rendering                                                          */
  /* ------------------------------------------------------------------ */
  var trail = [];
  var current = null;
  var extraCrumb = null;      // title of a detail page that is not in the menu

  function linkHtml(item, cls, withDesc) {
    var inTrail = trail.indexOf(item) > -1;
    return '<a class="' + cls + (inTrail ? ' is-trail' : '') + '" href="' + item.href + '"' +
      (item === current ? ' aria-current="page"' : '') + '>' + esc(T(item)) +
      (withDesc && item.desc ? '<span class="sub-desc" lang="en">' + esc(item.desc) + '</span>' : '') + '</a>';
  }

  function subList(items, level, withDesc) {
    return '<ul class="sub sub--l' + level + '">' + items.map(function (it) {
      return '<li>' + linkHtml(it, 'sub-link', withDesc) +
        (it.children ? subList(it.children, level + 1, it.showChildDesc) : '') + '</li>';
    }).join('') + '</ul>';
  }

  function hasDescs(items) {
    return items.some(function (it) { return it.showChildDesc || (it.children && hasDescs(it.children)); });
  }

  function topItem(item, idx) {
    var has = item.children && item.children.length;
    var id = 'submenu-' + idx;
    return '<li class="nav-item' + (has ? ' has-sub' : '') + '">' +
      '<div class="nav-row">' + linkHtml(item, 'nav-link') +
      (has ? '<button type="button" class="sub-toggle" aria-expanded="false" aria-controls="' + id +
        '" aria-label="' + esc(T(item)) + UI[lang].submenu + '"><span aria-hidden="true">▾</span></button>' : '') +
      '</div>' +
      (has ? '<div class="dropdown' + (hasDescs(item.children) ? ' dropdown--wide' : '') + '" id="' + id + '">' +
        subList(item.children, 1, false) + '</div>' : '') +
      '</li>';
  }

  function langSwitchHtml() {
    return '<div class="lang-switch" role="group" aria-label="Language / ভাষা">' +
      '<button type="button" data-lang="en" lang="en" aria-pressed="' + (lang === 'en') + '">EN</button>' +
      '<button type="button" data-lang="bn" lang="bn" aria-pressed="' + (lang === 'bn') + '">বাংলা</button>' +
      '</div>';
  }

  function renderHeader() {
    var el = document.getElementById('site-header');
    if (!el) { return; }
    el.innerHTML =
      '<div class="header-bar">' +
        '<a class="brand" href="index.html" aria-label="CLEAR Hub – home">' +
          '<img class="brand__wide" src="images/brand/logo-wide.png" alt="CLEAR Hub" width="171" height="56">' +
          '<img class="brand__square" src="images/brand/logo-square.png" alt="" width="44" height="44">' +
          '<span class="brand__text" aria-hidden="true">CLEAR Hub</span>' +
        '</a>' +
        '<nav id="primary-nav" class="primary-nav" aria-label="Main">' +
          '<ul>' + NAV.map(topItem).join('') + '</ul>' +
        '</nav>' +
        langSwitchHtml() +
        '<button type="button" class="nav-toggle" aria-expanded="false" aria-controls="primary-nav" aria-label="' + UI[lang].menu + '">' +
          '<span aria-hidden="true">☰</span></button>' +
      '</div>';
    bindHeader(el);
  }

  function renderFooter() {
    var el = document.getElementById('site-footer');
    if (!el) { return; }
    var u = UI[lang];

    var links = NAV.concat(FOOTER_LINKS).map(function (it) {
      return '<li><a href="' + it.href + '">' + esc(T(it)) + '</a></li>';
    }).join('');

    var social = ['facebook', 'linkedin', 'bluesky'].map(function (k) {
      var url = CONTACT.social[k];
      return '<li>' + (url
        ? '<a href="' + esc(url) + '" target="_blank" rel="noopener">' + u.social[k] + '</a>'
        : '<span class="tbd">' + u.social[k] + ' – ' + u.tbd + '</span>') + '</li>';
    }).join('');

    el.innerHTML =
      '<div class="container">' +
        '<div class="footer-grid">' +
          '<div class="footer-brand"><strong>CLEAR Hub</strong><p>' + u.tagline + '</p></div>' +
          '<div><h2 class="footer-h">' + u.explore + '</h2><ul class="footer-links">' + links + '</ul></div>' +
          '<div><h2 class="footer-h">' + u.follow + '</h2><ul class="social-list">' + social + '</ul></div>' +
        '</div>' +
        '<p class="footer-base">' + u.rights + ' · ' + u.credit +
          ' <a href="https://tuhinitsme.github.io" target="_blank" rel="noopener">tuhinitsme</a></p>' +
      '</div>';
  }

  function renderBreadcrumbs() {
    [].forEach.call(document.querySelectorAll('[data-breadcrumb]'), function (el) {
      if ((!trail.length && !extraCrumb) || currentFile() === 'index.html') { el.hidden = true; return; }
      var parts = ['<li><a href="index.html">' + UI[lang].home + '</a></li>'];
      trail.forEach(function (it, i) {
        var last = i === trail.length - 1 && !extraCrumb;
        parts.push(last
          ? '<li><span aria-current="page">' + esc(T(it)) + '</span></li>'
          : '<li><a href="' + it.href + '">' + esc(T(it)) + '</a></li>');
      });
      if (extraCrumb) { parts.push('<li><span aria-current="page">' + esc(extraCrumb) + '</span></li>'); }
      el.setAttribute('aria-label', UI[lang].crumb);
      el.innerHTML = '<ol>' + parts.join('') + '</ol>';
      el.hidden = false;
    });
  }

  function renderCards() {
    [].forEach.call(document.querySelectorAll('[data-section-cards]'), function (el) {
      var parent = findByLabel(NAV, el.getAttribute('data-section-cards'));
      if (!parent || !parent.children) { return; }
      el.innerHTML = parent.children.map(function (item) {
        var chips = (item.children || []).map(function (c) {
          return '<li><a href="' + c.href + '">' + esc(T(c)) + '</a></li>';
        }).join('');
        return '<article class="card">' +
          '<div class="card-icon" aria-hidden="true">' + (item.icon || '📄') + '</div>' +
          '<h2><a class="card-link" href="' + item.href + '">' + esc(T(item)) + '</a></h2>' +
          '<p lang="en">' + esc(item.desc || '') + '</p>' +
          (chips ? '<ul class="chips" aria-label="' + UI[lang].includes + '">' + chips + '</ul>' : '') +
          '</article>';
      }).join('');
    });
  }

  /* Notice shown in Bangla mode because page content is not translated yet. */
  function renderNotice() {
    var old = document.getElementById('lang-notice');
    if (old) { old.parentNode.removeChild(old); }
    if (lang !== 'bn') { return; }
    var main = document.getElementById('main');
    if (!main) { return; }
    var div = document.createElement('div');
    div.id = 'lang-notice';
    div.className = 'lang-notice';
    div.setAttribute('role', 'note');
    div.innerHTML = '<p lang="bn">' + UI.bn.notice + '</p>' +
      '<button type="button" class="lang-notice__btn" data-lang="en">' + UI.bn.switchTo + '</button>';
    main.parentNode.insertBefore(div, main);
    div.querySelector('button').addEventListener('click', function () { setLang('en'); });
  }

  /* ------------------------------------------------------------------ */
  /* language switching                                                 */
  /* ------------------------------------------------------------------ */
  function setLang(next) {
    if (next === lang) { return; }
    store('clearhub-lang', next);
    // If a translated twin of this page exists, go there.
    var alt = document.querySelector('link[rel="alternate"][hreflang="' + next + '"]');
    if (alt && alt.getAttribute('href') && alt.getAttribute('href') !== currentFile()) {
      location.href = alt.getAttribute('href');
      return;
    }
    lang = next;
    document.documentElement.lang = lang;
    renderAll();
    var btn = document.querySelector('.lang-switch [data-lang="' + next + '"]');
    if (btn) { btn.focus(); }
  }

  /* ------------------------------------------------------------------ */
  /* behaviour: dropdowns, mobile menu, keyboard                        */
  /* ------------------------------------------------------------------ */
  function subItems(root) { return [].slice.call(root.querySelectorAll('.nav-item.has-sub')); }

  function setOpen(li, open) {
    li.classList.toggle('open', open);
    li.querySelector('.sub-toggle').setAttribute('aria-expanded', open ? 'true' : 'false');
    var dd = li.querySelector('.dropdown');
    dd.classList.remove('align-right');
    if (open && DESKTOP.matches && dd.getBoundingClientRect().right > window.innerWidth - 8) {
      dd.classList.add('align-right');            // keep wide dropdowns on screen
    }
  }

  function closeAll(root, except) {
    subItems(root).forEach(function (li) { if (li !== except) { setOpen(li, false); } });
  }

  function closeMobileNav(root) {
    var nav = root.querySelector('.primary-nav');
    var btn = root.querySelector('.nav-toggle');
    if (!nav || !btn) { return; }
    nav.classList.remove('open');
    btn.setAttribute('aria-expanded', 'false');
    btn.firstChild.textContent = '☰';
  }

  function bindHeader(root) {
    var nav = root.querySelector('.primary-nav');
    var burger = root.querySelector('.nav-toggle');

    burger.addEventListener('click', function () {
      var open = nav.classList.toggle('open');
      burger.setAttribute('aria-expanded', open ? 'true' : 'false');
      burger.firstChild.textContent = open ? '✕' : '☰';
    });

    [].forEach.call(root.querySelectorAll('.lang-switch button'), function (b) {
      b.addEventListener('click', function () { setLang(b.getAttribute('data-lang')); });
    });

    subItems(root).forEach(function (li) {
      var btn = li.querySelector('.sub-toggle');
      var timer;

      btn.addEventListener('click', function (e) {
        var isOpen = li.classList.contains('open');
        // A mouse click on a menu that hover already opened should not close it.
        if (DESKTOP.matches && e.detail > 0 && isOpen) { return; }
        closeAll(root, li);
        setOpen(li, !isOpen);
      });
      li.addEventListener('mouseenter', function () {
        if (!DESKTOP.matches) { return; }
        clearTimeout(timer); closeAll(root, li); setOpen(li, true);
      });
      li.addEventListener('mouseleave', function () {
        if (!DESKTOP.matches) { return; }
        timer = setTimeout(function () { setOpen(li, false); }, 160);
      });
      li.addEventListener('focusout', function (e) {
        if (DESKTOP.matches && e.relatedTarget && !li.contains(e.relatedTarget)) { setOpen(li, false); }
      });
    });
  }

  // Any link in the header: close open menus (important for same-page #section links).
  // Bound once on the persistent container, because the menu is re-rendered.
  (function () {
    var root = document.getElementById('site-header');
    if (!root) { return; }
    root.addEventListener('click', function (e) {
      if (e.target.closest && e.target.closest('a') && root.firstChild) {
        closeAll(root); closeMobileNav(root);
      }
    });
  })();

  document.addEventListener('keydown', function (e) {
    if (e.key !== 'Escape') { return; }
    var root = document.getElementById('site-header');
    if (!root || !root.firstChild) { return; }
    var openLi = subItems(root).filter(function (li) { return li.classList.contains('open'); })[0];
    var navOpen = root.querySelector('.primary-nav').classList.contains('open');
    if (openLi) {
      var hadFocus = openLi.contains(document.activeElement);
      closeAll(root);
      if (hadFocus) { openLi.querySelector('.sub-toggle').focus(); }
    } else if (navOpen) {
      closeMobileNav(root);
      root.querySelector('.nav-toggle').focus();
    }
  });

  document.addEventListener('click', function (e) {
    var root = document.getElementById('site-header');
    if (root && root.firstChild && !root.contains(e.target)) { closeAll(root); }
  });

  DESKTOP.addEventListener('change', function () {
    var root = document.getElementById('site-header');
    if (root && root.firstChild) { closeAll(root); closeMobileNav(root); }
  });

  /* ------------------------------------------------------------------ */
  /* start                                                              */
  /* ------------------------------------------------------------------ */
  function computeTrail() {
    trail = findTrail(NAV, isHere) || [];
    current = trail.length ? trail[trail.length - 1] : null;
    extraCrumb = null;
    var parent = document.body.getAttribute('data-parent');   // e.g. <body data-parent="articles.html">
    if (!trail.length && !parent) {                       // footer-only page, e.g. Contact us
      var f = FOOTER_LINKS.filter(function (it) { return it.href === currentFile(); })[0];
      if (f) { extraCrumb = T(f); }
    }
    if (!trail.length && parent) {
      trail = findTrail(NAV, function (it) { return it.href === parent; }) || [];
      current = null;                                   // the page itself is not in the menu
      var h1 = document.querySelector('h1');
      extraCrumb = h1 ? h1.textContent.trim() : document.title;
    }
  }

  function refresh() {
    computeTrail();
    renderHeader();
    renderBreadcrumbs();
  }

  function renderAll() {
    refresh();
    renderCards();
    renderFooter();
    renderNotice();
  }

  window.ClearHub = { contact: CONTACT };

  initLang();
  renderAll();
  window.addEventListener('hashchange', refresh);   // keeps highlight right for #section links
})();
