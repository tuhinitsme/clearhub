/* "Research in three levels" tabs: everyday explanation / more detail / original evidence.
   Markup: [data-levels] containing role="tab" buttons and role="tabpanel" panels. */
(function () {
    'use strict';

    [].forEach.call(document.querySelectorAll('[data-levels]'), function (root) {
        var tabs = [].slice.call(root.querySelectorAll('[role="tab"]'));
        var panels = tabs.map(function (t) { return document.getElementById(t.getAttribute('aria-controls')); });

        function select(i, focus) {
            tabs.forEach(function (t, j) {
                var on = i === j;
                t.setAttribute('aria-selected', on ? 'true' : 'false');
                t.tabIndex = on ? 0 : -1;
                panels[j].hidden = !on;
            });
            if (focus) { tabs[i].focus(); }
        }

        tabs.forEach(function (t, i) {
            t.addEventListener('click', function () { select(i, false); });
            t.addEventListener('keydown', function (e) {
                var n = tabs.length;
                if (e.key === 'ArrowRight') { e.preventDefault(); select((i + 1) % n, true); }
                if (e.key === 'ArrowLeft')  { e.preventDefault(); select((i - 1 + n) % n, true); }
                if (e.key === 'Home')       { e.preventDefault(); select(0, true); }
                if (e.key === 'End')        { e.preventDefault(); select(n - 1, true); }
            });
        });

        select(0, false);
    });
})();
