/* Stories and Puzzles – switches between the two activities.
   The URL hash decides which one is shown (#stories or #comic-puzzle),
   so menu links, bookmarks and the back button all work. */
(function () {
    'use strict';

    var panels = {
        'stories': document.getElementById('stories'),
        'comic-puzzle': document.getElementById('comic-puzzle')
    };
    var buttons = [].slice.call(document.querySelectorAll('.switch-btn'));
    var bar = document.getElementById('activity-tabs');
    var clickedButton = false;

    function show(id, scroll) {
        if (!panels[id]) { id = 'stories'; }

        Object.keys(panels).forEach(function (key) {
            panels[key].hidden = (key !== id);
        });

        buttons.forEach(function (btn) {
            var on = btn.getAttribute('data-panel') === id;
            btn.classList.toggle('active', on);
            btn.setAttribute('aria-selected', on ? 'true' : 'false');
            btn.tabIndex = on ? 0 : -1;
        });

        if (scroll) {
            var reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
            bar.scrollIntoView({ behavior: reduce ? 'auto' : 'smooth', block: 'start' });
        }
    }

    function go(id) {
        // Update the URL without a page jump (keeps keyboard focus on the tab),
        // then tell the page and the menu that the hash changed.
        if (location.hash !== '#' + id) { history.pushState(null, '', '#' + id); }
        clickedButton = true;               // no page scroll when the visitor uses the tabs themselves
        window.dispatchEvent(new HashChangeEvent('hashchange'));
    }

    buttons.forEach(function (btn, i) {
        btn.addEventListener('click', function () { go(btn.getAttribute('data-panel')); });

        btn.addEventListener('keydown', function (e) {      // arrow keys move between tabs
            var next = null;
            if (e.key === 'ArrowRight') { next = buttons[(i + 1) % buttons.length]; }
            if (e.key === 'ArrowLeft')  { next = buttons[(i - 1 + buttons.length) % buttons.length]; }
            if (next) { e.preventDefault(); next.focus(); go(next.getAttribute('data-panel')); }
        });
    });

    window.addEventListener('hashchange', function () {
        show(location.hash.replace('#', ''), !clickedButton);
        clickedButton = false;
    });

    show(location.hash.replace('#', ''), !!location.hash);
})();
